cd `dirname $0`
 ROOT_PATH=`pwd`
java -Xms256M -Xmx1024M -cp classpath.jar: prj_analise_tdq.job_01_rad_execucao_profiler_1_0.job_01_rad_execucao_profiler --context=Producao "$@" 