// ============================================================================
//
// Copyright (C) 2006-2011 Talend Inc. - www.talend.com
//
// This source code is available under agreement available at
// %InstallDIR%\features\org.talend.rcp.branding.%PRODUCTNAME%\%PRODUCTNAME%license.txt
//
// You should have received a copy of the agreement
// along with this program; if not, write to Talend SA
// 9 rue Pages 92150 Suresnes, France
//
// ============================================================================
package routines.system;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DBManagerFactory {

    private static Map<String, DBManager> managerMap = new HashMap<String, DBManager>();

    public static DBManager getDBManager(String dbmsId) {
        DBManager manager = managerMap.get(dbmsId);

        if (manager == null) {
            DBMSConstants curDBMS = null;
            for (DBMSConstants dbms : DBMSConstants.values()) {
                if (dbmsId.equalsIgnoreCase(dbms.getDBmsId())) {
                    curDBMS = dbms;
                    break;
                }
            }
            if (curDBMS == DBMSConstants.AS400) {
                manager = new AS400Manager(curDBMS.getDBmsId());
            } else if (curDBMS == DBMSConstants.ACCESS) {
                manager = new AccessManager(curDBMS.getDBmsId());
            } else if (curDBMS == DBMSConstants.DB2) {
                manager = new DB2Manager(curDBMS.getDBmsId());
            } else if (curDBMS == DBMSConstants.FIREBIRD) {
                manager = new FirebirdManager(curDBMS.getDBmsId());
            } else if (curDBMS == DBMSConstants.HSQLDB) {
                manager = new HSQLDBManager(curDBMS.getDBmsId());
            } else if (curDBMS == DBMSConstants.INFORMIX) {
                manager = new InformixManager(curDBMS.getDBmsId());
            } else if (curDBMS == DBMSConstants.INGRES) {
                manager = new IngresManager(curDBMS.getDBmsId());
            } else if (curDBMS == DBMSConstants.VECTORWISE) {
                manager = new VectorWiseManager(curDBMS.getDBmsId());
            } else if (curDBMS == DBMSConstants.INTERBASE) {
                manager = new InterbaseManager(curDBMS.getDBmsId());
            } else if (curDBMS == DBMSConstants.JAVADB) {
                manager = new JavaDBManager(curDBMS.getDBmsId());
            } else if (curDBMS == DBMSConstants.MAXDB) {
                manager = new MaxDBManager(curDBMS.getDBmsId());
            } else if (curDBMS == DBMSConstants.MSSQL) {
                manager = new MSSQLManager(curDBMS.getDBmsId());
            } else if (curDBMS == DBMSConstants.MYSQL) {
                manager = new MysqlManager(curDBMS.getDBmsId());
            } else if (curDBMS == DBMSConstants.NETEZZA) {
                manager = new NetezzaManager(curDBMS.getDBmsId());
            } else if (curDBMS == DBMSConstants.ORACLE) {
                manager = new OracleManager(curDBMS.getDBmsId());
            } else if (curDBMS == DBMSConstants.POSTGREPLUS) {
                manager = new PostgrePlusManager(curDBMS.getDBmsId());
            } else if (curDBMS == DBMSConstants.POSTGRESQL) {
                manager = new PostgreManager(curDBMS.getDBmsId());
            } else if (curDBMS == DBMSConstants.SQLITE) {
                manager = new SQLiteManager(curDBMS.getDBmsId());
            } else if (curDBMS == DBMSConstants.SYBASE) {
                manager = new SybaseManager(curDBMS.getDBmsId());
            } else if (curDBMS == DBMSConstants.TERADATA) {
                manager = new TeradataManager(curDBMS.getDBmsId());
            } else if (curDBMS == DBMSConstants.VERTICA) {
                manager = new VerticaManager(curDBMS.getDBmsId());
            } else if (curDBMS == DBMSConstants.ODBC) {
                manager = new ODBCManager(curDBMS.getDBmsId());
            }
        }
        managerMap.put(dbmsId, manager);
        return manager;
    }
}

abstract class DBManager {

    protected abstract String getLProtectedChar();

    protected abstract String getRProtectedChar();

    protected abstract String getDBMSId();

    protected String getLProtectedChar(String columName) {
        return getLProtectedChar();
    }

    protected String getRProtectedChar(String columName) {
        return getRProtectedChar();
    }

    private String getSqlStmt(DynamicMetadata column) {
        if (column != null) {
            if (column.getType().equals("id_Geometry"))
                return "GeomFromText(?, ?)"; // For PostGIS
            else
                return "?";
        } else {
            return "?";
        }
    }

    public String getUpdateSetSQL(Dynamic dynamic) {
        StringBuilder updateSetStmt = new StringBuilder();
        String ending = ",";
        for (int i = 0; i < dynamic.getColumnCount(); i++) {
            DynamicMetadata column = dynamic.getColumnMetadata(i);
            updateSetStmt.append(getLProtectedChar(column.getName()) + column.getName() + getRProtectedChar(column.getName())
                    + " = " + getSqlStmt(column));
            if (i >= dynamic.getColumnCount() - 1) {
                ending = "";
            }
            updateSetStmt.append(ending);
        }

        return updateSetStmt.toString();
    }

    public String getInsertTableSQL(Dynamic dynamic) {

        StringBuilder createSQL = new StringBuilder();
        String ending = ",";

        for (int i = 0; i < dynamic.getColumnCount(); i++) {
            DynamicMetadata column = dynamic.getColumnMetadata(i);
            createSQL.append(getLProtectedChar(column.getName()) + column.getName() + getRProtectedChar(column.getName()) + " ");
            if (i >= dynamic.getColumnCount() - 1) {
                ending = "";
            }
            createSQL.append(ending);
        }

        return createSQL.toString();
    }

    public String getCreateTableSQL(Dynamic dynamic) {

        StringBuilder createSQL = new StringBuilder();
        List<String> pkList = new ArrayList<String>();
        String ending = ",";

        for (int i = 0; i < dynamic.getColumnCount(); i++) {
            DynamicMetadata column = dynamic.getColumnMetadata(i);
            if (column.isKey()) {
                pkList.add(getLProtectedChar(column.getName()) + column.getName() + getRProtectedChar(column.getName()));
            }
            createSQL.append(getLProtectedChar(column.getName()) + column.getName() + getRProtectedChar(column.getName()) + " ");
            String dataType = Dynamic.getDefaultSelectedDbType(getDBMSId(), column.getType());
            if (dataType == null || ("").equals(dataType)) {
                dataType = column.getDbType();
            }
            // createSQL.append(dataType);
            if ("mysql_id".equalsIgnoreCase(getDBMSId()) && dataType.endsWith("UNSIGNED")) {
                createSQL.append(dataType.substring(0, dataType.indexOf("UNSIGNED")));
            } else {
                createSQL.append(dataType);
            }

            boolean lengthIgnored = ("true").equals(MetadataTalendType.getDefaultDBTypes(getDBMSId(), dataType,
                    MetadataTalendType.IGNORE_LEN));
            Integer length = column.getLength();
            if (length.intValue() <= 0) {
                String defaultLen = MetadataTalendType.getDefaultDBTypes(getDBMSId(), dataType,
                        MetadataTalendType.DEFAULT_LENGTH);
                if (defaultLen != null && !("").equals(defaultLen)) {
                    length = Integer.parseInt(defaultLen);
                }
            }
            boolean precisionIgnored = ("true").equals(MetadataTalendType.getDefaultDBTypes(getDBMSId(), dataType,
                    MetadataTalendType.IGNORE_PRE));
            Integer precision = column.getPrecision();
            if (precision.intValue() <= 0) {
                String strPrecision = MetadataTalendType.getDefaultDBTypes(getDBMSId(), dataType,
                        MetadataTalendType.DEFAULT_PRECISION);
                if (strPrecision != null && !("").equals(strPrecision)) {
                    precision = Integer.parseInt(strPrecision);
                }
            }
            String prefix = "";
            String suffix = "";
            String comma = "";
            if (("oracle_id".equalsIgnoreCase(getDBMSId()))
                    && (("NUMBER".equalsIgnoreCase(dataType)) || ("CHAR".equalsIgnoreCase(dataType)) || ("NCHAR"
                            .equalsIgnoreCase(dataType))) && (length == null || length <= 0)
                    && (precision == null || precision <= 0)) {
            } else if (("mysql_id".equalsIgnoreCase(getDBMSId()))
                    && (("DECIMAL".equalsIgnoreCase(dataType)) || ("NUMERIC".equalsIgnoreCase(dataType)))
                    && (length == null || length <= 0) && (precision == null || precision <= 0)) {
            } else {

                if (!lengthIgnored) {
                    if (("postgres_id".equalsIgnoreCase(getDBMSId()) || "postgresplus_id".equalsIgnoreCase(getDBMSId()))
                            && length < 0) {
                    } else {
                        prefix = "(";
                        suffix = ") ";
                        createSQL.append(prefix + length);
                    }
                }
                if (!precisionIgnored) {
                    prefix = (prefix.equals("") ? "(" : prefix);
                    suffix = (suffix.equals("") ? ") " : suffix);
                    if (lengthIgnored) {
                        createSQL.append(prefix);
                        comma = "";
                    } else {
                        comma = ",";
                    }
                    createSQL.append(comma + precision);
                }
                if (("postgres_id".equalsIgnoreCase(getDBMSId()) || "postgresplus_id".equalsIgnoreCase(getDBMSId()))
                        && length < 0) {
                } else {
                    createSQL.append(suffix);
                }
                if ("mysql_id".equalsIgnoreCase(getDBMSId()) && dataType.endsWith("UNSIGNED")) {
                    createSQL.append("UNSIGNED");
                }

            }
            createSQL.append(setNullable(column.isNullable()));
            if (i >= dynamic.getColumnCount() - 1) {
                ending = "";
            }
            createSQL.append(ending);
        }

        return createSQL.toString();
    }

    protected String setNullable(boolean nullable) {
        if (!nullable) {
            return " not null ";
        } else {
            return "";
        }
    }

}

class AccessManager extends DBManager {

    private String dbmsId;

    public AccessManager(String dbmsId) {
        super();
        this.dbmsId = dbmsId;
    }

    protected String getDBMSId() {

        return this.dbmsId;
    }

    protected String getLProtectedChar() {
        return "[";
    }

    protected String getRProtectedChar() {
        return "]";
    }

}

class AS400Manager extends DBManager {

    private String dbmsId;

    public AS400Manager(String dbmsId) {
        super();
        this.dbmsId = dbmsId;
    }

    protected String getDBMSId() {
        return this.dbmsId;
    }

    protected String getLProtectedChar() {
        return "";
    }

    protected String getRProtectedChar() {
        return "";
    }

}

class DB2Manager extends DBManager {

    private String dbmsId;

    public DB2Manager(String dbmsId) {
        super();
        this.dbmsId = dbmsId;
    }

    protected String getDBMSId() {
        // TODO Auto-generated method stub
        return this.dbmsId;
    }

    protected String getLProtectedChar() {
        return "\"";
    }

    protected String getRProtectedChar() {
        return "\"";
    }
}

class FirebirdManager extends DBManager {

    private String dbmsId;

    public FirebirdManager(String dbmsId) {
        super();
        this.dbmsId = dbmsId;
    }

    protected String getDBMSId() {
        // TODO Auto-generated method stub
        return this.dbmsId;
    }

    protected String getLProtectedChar() {
        return " ";
    }

    protected String getRProtectedChar() {
        return " ";
    }

}

class HSQLDBManager extends DBManager {

    private String dbmsId;

    String[] hsqldbKeyWords = {};

    public HSQLDBManager(String dbmsId) {
        super();
        this.dbmsId = dbmsId;
    }

    protected String getDBMSId() {
        // TODO Auto-generated method stub
        return this.dbmsId;
    }

    protected String getLProtectedChar() {
        return "";
    }

    protected String getRProtectedChar() {
        return "";
    }

    protected boolean isHSQLDBKeyword(String keyword) {
        for (int i = 0; i < hsqldbKeyWords.length; i++) {
            if (hsqldbKeyWords[i].equalsIgnoreCase(keyword)) {
                return true;
            }
        }
        return false;
    }

    protected String getLProtectedChar(String keyword) {
        if (isHSQLDBKeyword(keyword)) {
            return "\"";
        }
        return getLProtectedChar();
    }

    protected String getRProtectedChar(String keyword) {
        if (isHSQLDBKeyword(keyword)) {
            return "\"";
        }
        return getRProtectedChar();
    }

}

class InformixManager extends DBManager {

    private String dbmsId;

    public InformixManager(String dbmsId) {
        super();
        this.dbmsId = dbmsId;
    }

    /*
     * (non-Javadoc)
     * 
     * @see routines.system.dbmanager.DBManager#getDBMSId()
     */
    @Override
    protected String getDBMSId() {
        // TODO Auto-generated method stub
        return this.dbmsId;
    }

    protected String getLProtectedChar() {
        return "";
    }

    protected String getRProtectedChar() {
        return "";
    }

}

class IngresManager extends DBManager {

    private String dbmsId;

    public IngresManager(String dbmsId) {
        super();
        this.dbmsId = dbmsId;
    }

    protected String getDBMSId() {
        // TODO Auto-generated method stub
        return this.dbmsId;
    }

    protected String getLProtectedChar() {
        return "\"";
    }

    protected String getRProtectedChar() {
        return "\"";
    }

}

class InterbaseManager extends DBManager {

    private String dbmsId;

    public InterbaseManager(String dbmsId) {
        super();
        this.dbmsId = dbmsId;
    }

    protected String getDBMSId() {
        // TODO Auto-generated method stub
        return this.dbmsId;
    }

    protected String getLProtectedChar() {
        return "\"";
    }

    protected String getRProtectedChar() {
        return "\"";
    }

}

class JavaDBManager extends DBManager {

    private String dbmsId;

    public JavaDBManager(String dbmsId) {
        super();
        this.dbmsId = dbmsId;
    }

    protected String getDBMSId() {
        // TODO Auto-generated method stub
        return this.dbmsId;
    }

    protected String getLProtectedChar() {
        return "\"";
    }

    protected String getRProtectedChar() {
        return "\"";
    }

}

class JDBCManager extends DBManager {

    private String dbmsId;

    public JDBCManager(String dbmsId) {
        super();
        this.dbmsId = dbmsId;
    }

    protected String getDBMSId() {
        // TODO Auto-generated method stub
        return this.dbmsId;
    }

    protected String getLProtectedChar() {
        return "";
    }

    protected String getRProtectedChar() {
        return "";
    }

}

class MaxDBManager extends DBManager {

    private String dbmsId;

    public MaxDBManager(String dbmsId) {
        super();
        this.dbmsId = dbmsId;
    }

    protected String getDBMSId() {
        // TODO Auto-generated method stub
        return this.dbmsId;
    }

    protected String getLProtectedChar() {
        return "";
    }

    protected String getRProtectedChar() {
        return "";
    }

}

class MSSQLManager extends DBManager {

    private String dbmsId;

    public MSSQLManager(String dbmsId) {
        super();
        this.dbmsId = dbmsId;
    }

    protected String getDBMSId() {
        // TODO Auto-generated method stub
        return this.dbmsId;
    }

    protected String getLProtectedChar() {
        return "[";
    }

    protected String getRProtectedChar() {
        return "]";
    }

}

class MysqlManager extends DBManager {

    private String dbmsId;

    public MysqlManager(String dbmsId) {
        super();
        this.dbmsId = dbmsId;
    }

    protected String getDBMSId() {
        // TODO Auto-generated method stub
        return this.dbmsId;
    }

    protected String getLProtectedChar() {
        return "`";
    }

    protected String getRProtectedChar() {
        return "`";
    }

}

class NetezzaManager extends DBManager {

    private String dbmsId;

    public NetezzaManager(String dbmsId) {
        super();
        this.dbmsId = dbmsId;
    }

    protected String getDBMSId() {
        // TODO Auto-generated method stub
        return this.dbmsId;
    }

    protected String getLProtectedChar() {
        return "";
    }

    protected String getRProtectedChar() {
        return "";
    }

}

class ODBCManager extends DBManager {

    private String dbmsId;

    public ODBCManager(String dbmsId) {
        super();
        this.dbmsId = dbmsId;
    }

    protected String getDBMSId() {
        // TODO Auto-generated method stub
        return this.dbmsId;
    }

    protected String getLProtectedChar() {
        return "";
    }

    protected String getRProtectedChar() {
        return "";
    }

}

class OracleManager extends DBManager {

    private String[] oracleKeyWords = { "ACCESS", "AUDIT", "COMPRESS", "DESC", "ADD", "CONNECT", "DISTINCT", "ALL", "BY",
            "CREATE", "DROP", "ALTER", "CHAR", "CURRENT", "ELSE", "AND", "CHECK", "DATE", "EXCLUSIVE", "ANY", "CLUSTER",
            "DECIMAL", " EXISTS", "AS", "COLUMN", "DEFAULT", "FILE", "ASC", "COMMENT", "DELETE", "FLOAT", "FOR", "LONG",
            "PCTFREE", "SUCCESSFUL", "FROM", "MAXEXTENTS", "PRIOR", "SYNONYM", "GRANT", "MINUS", "PRIVILEGES", "SYSDATE",
            "GROUP", "MODE", "PUBLIC", "TABLE", "HAVING", "MODIFY", "RAW", "THEN", "IDENTIFIED", "NETWORK", "RENAME", "TO",
            "IMMEDIATE", "NOAUDIT", "RESOURCE", "TRIGGER", "IN", "NOCOMPRESS", "REVOKE", "UID", "INCREMENT", "NOT", "ROW",
            "UNION", "INDEX", "NOWAIT", "ROWID", "UNIQUE", "INITIAL", "NULL", "ROWNUM", "UPDATE", "INSERT", "NUMBER", "ROWS",
            "USER", "INTEGER", "OF", "SELECT", "VALIDATE", "INTERSECT", "OFFLINE", "SESSION", "VALUES", "INTO", "ON", "SET",
            "VARCHAR", "IS", "ONLINE", "SHARE", "VARCHAR2", "LEVEL", "OPTION", "SIZE", "VIEW", "LIKE", "OR", "SMALLINT",
            "WHENEVER", "LOCK", "ORDER", "START", "WHERE", "WITH" };

    private String dbmsId;

    public OracleManager(String dbmsId) {
        super();
        this.dbmsId = dbmsId;
    }

    protected String getLProtectedChar() {
        return "";
    }

    protected String getRProtectedChar() {
        return "";
    }

    protected String getDBMSId() {
        return dbmsId;
    }

    protected boolean isOracleKeyword(String keyword) {
        for (int i = 0; i < oracleKeyWords.length; i++) {
            if (oracleKeyWords[i].equalsIgnoreCase(keyword)) {
                return true;
            }
        }
        return false;
    }

    protected boolean contaionsSpaces(String columnName) {
        if (columnName != null) {
            // bug0016837 when use Additional column the coulmn name like: " + "columnNmae" + "
            if (columnName.startsWith("\" + ") && columnName.endsWith(" + \"")) {
                return false;
            }

            if (columnName.contains(" ")) {
                return true;
            }
        }
        return false;
    }

    protected String getLProtectedChar(String keyword) {
        if (isOracleKeyword(keyword) || contaionsSpaces(keyword)) {
            return "\"";
        }
        return getLProtectedChar();
    }

    protected String getRProtectedChar(String keyword) {
        if (isOracleKeyword(keyword) || contaionsSpaces(keyword)) {
            return "\"";
        }
        return getRProtectedChar();
    }
}

class PostgreManager extends DBManager {

    private String dbmsId;

    public PostgreManager(String dbmsId) {
        super();
        this.dbmsId = dbmsId;
    }

    protected String getDBMSId() {
        // TODO Auto-generated method stub
        return dbmsId;
    }

    protected String getLProtectedChar() {
        return "\"";
    }

    protected String getRProtectedChar() {
        return "\"";
    }

}

class PostgrePlusManager extends DBManager {

    private String dbmsId;

    public PostgrePlusManager(String dbmsId) {
        super();
        this.dbmsId = dbmsId;
    }

    protected String getDBMSId() {
        // TODO Auto-generated method stub
        return this.dbmsId;
    }

    protected String getLProtectedChar() {
        return "\"";
    }

    protected String getRProtectedChar() {
        return "\"";
    }

}

class SQLiteManager extends DBManager {

    private String dbmsId;

    public SQLiteManager(String dbmsId) {
        super();
        this.dbmsId = dbmsId;
    }

    protected String getDBMSId() {
        // TODO Auto-generated method stub
        return this.dbmsId;
    }

    protected String getLProtectedChar() {
        return "\"";
    }

    protected String getRProtectedChar() {
        return "\"";
    }

}

class SybaseManager extends DBManager {

    private String dbmsId;

    private String[] sybaseKeyWords = { "ACCESS", "AUDIT", "COMPRESS", "DESC", "ADD", "CONNECT", "COUNT", "DISTINCT", "ALL",
            "BY", "CREATE", "DROP", "ALTER", "CHAR", "CURRENT", "ELSE", "AND", "CHECK", "DATE", "EXCLUSIVE", "ANY", "CLUSTER",
            "DECIMAL", " EXISTS", "AS", "COLUMN", "DEFAULT", "FILE", "ASC", "COMMENT", "DELETE", "FLOAT", "FOR", "LONG",
            "PCTFREE", "SUCCESSFUL", "FROM", "FALSE", "MAXEXTENTS", "PRIOR", "SYNONYM", "GRANT", "MINUS", "PRIVILEGES",
            "SYSDATE", "GROUP", "MODE", "PUBLIC", "TABLE", "HAVING", "MODIFY", "RAW", "THEN", "IDENTIFIED", "NETWORK", "RENAME",
            "TO", "IMMEDIATE", "NOAUDIT", "RESOURCE", "TRIGGER", "IN", "NOCOMPRESS", "REVOKE", "UID", "INCREMENT", "NOT", "ROW",
            "UNION", "INDEX", "NOWAIT", "ROWID", "UNIQUE", "INITIAL", "NULL", "ROWNUM", "UPDATE", "INSERT", "NUMBER", "ROWS",
            "USER", "INTEGER", "OF", "SELECT", "VALIDATE", "INTERSECT", "OFFLINE", "SESSION", "VALUES", "INTO", "ON", "SET",
            "VARCHAR", "IS", "ONLINE", "SHARE", "LEVEL", "OPTION", "SIZE", "VIEW", "LIKE", "OR", "SMALLINT", "WHENEVER", "LOCK",
            "ORDER", "START", "WHERE", "WITH"

    };

    public SybaseManager(String dbmsId) {
        super();
        this.dbmsId = dbmsId;
    }

    protected String getDBMSId() {
        // TODO Auto-generated method stub
        return this.dbmsId;
    }

    protected String getLProtectedChar() {
        return "";
    }

    protected String getRProtectedChar() {
        return "";
    }

    protected boolean isSybaseKeyword(String keyword) {
        for (int i = 0; i < sybaseKeyWords.length; i++) {
            if (sybaseKeyWords[i].equalsIgnoreCase(keyword)) {
                return true;
            }
        }
        return false;
    }

    protected String getLProtectedChar(String keyword) {
        if (isSybaseKeyword(keyword)) {
            return "\"";
        }
        return getLProtectedChar();
    }

    protected String getRProtectedChar(String keyword) {
        if (isSybaseKeyword(keyword)) {
            return "\"";
        }
        return getRProtectedChar();
    }

    protected String setNullable(boolean nullable) {
        if (!nullable) {
            return " not null ";
        } else {
            return " null ";
        }
    }

}

class TeradataManager extends DBManager {

    private String dbmsId;

    public TeradataManager(String dbmsId) {
        super();
        this.dbmsId = dbmsId;
    }

    protected String getDBMSId() {
        // TODO Auto-generated method stub
        return dbmsId;
    }

    protected String getLProtectedChar() {
        return "\"";
    }

    protected String getRProtectedChar() {
        return "\"";
    }

}

class VectorWiseManager extends IngresManager {

    private String dbmsId;

    public VectorWiseManager(String dbmsId) {
        super(dbmsId);
        this.dbmsId = dbmsId;
    }

    protected String getDBMSId() {
        // TODO Auto-generated method stub
        return dbmsId;
    }

}

class VerticaManager extends DBManager {

    private String dbmsId;

    public VerticaManager(String dbmsId) {
        super();
        this.dbmsId = dbmsId;
    }

    protected String getDBMSId() {
        return this.dbmsId;
    }

    protected String getLProtectedChar() {
        return "";
    }

    protected String getRProtectedChar() {
        return "";
    }

}
