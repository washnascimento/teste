package routines;

import java.io.IOException;
import java.io.File;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import org.apache.http.*;
import org.apache.http.client.*;
import org.apache.http.client.methods.*;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.impl.client.DefaultHttpClient;

public class Rest_Attachment {


	public static String addAttachmentToIssue(String issueKey, String path) throws UnsupportedOperationException, IOException {

    HttpClient httpclient = new DefaultHttpClient();
    HttpPost httppost = new HttpPost("http://homologa.brics.rac.serpro.gov.br/api/1/message/" + issueKey + "/filemessage/new");
    httppost.setHeader("token", "869d8a019361594c8e5fcdb93cbaac4b93c2f621");
    MultipartEntity entity = new MultipartEntity(HttpMultipartMode.BROWSER_COMPATIBLE);

    File fileToUpload = new File(path);
    FileBody fileBody = new FileBody(fileToUpload);
    entity.addPart("file", fileBody);

    httppost.setEntity(entity);
    HttpResponse response = null;
    try {
        response = httpclient.execute(httppost);
    } catch (ClientProtocolException e) {
        return "erro";
    } catch (IOException e) {
        return "erro";
    }
    HttpEntity result = response.getEntity();
    
    BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
    
    if(response.getStatusLine().getStatusCode() == 200)
        return rd.readLine();
    else
        return "erro";

}
}
